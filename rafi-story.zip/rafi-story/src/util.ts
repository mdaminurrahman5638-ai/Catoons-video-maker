import {createContext, useContext} from 'react';
import {interpolate, useCurrentFrame} from 'remotion';

export const FPS = 30;
export const W = 1920;
export const H = 1080;
export const TOTAL = 4410; // 147s (audio 146.68s)
export const FONT = "'Hind Siliguri','Noto Sans Bengali',sans-serif";
export const OL = '#222222';

export const SceneStart = createContext(0);
/** absolute time (seconds) of the whole video, from inside any scene */
export const useT = (): number => {
  const f = useCurrentFrame();
  const s = useContext(SceneStart);
  return (f + s) / FPS;
};
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const prog = (t: number, a: number, d = 0.4) => clamp01((t - a) / d);
export const eo = (p: number) => 1 - Math.pow(1 - p, 3);
export const bo = (p: number) => {
  const c = 1.70158;
  return 1 + (c + 1) * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2);
};
export const kf = (t: number, pts: [number, number][]) =>
  interpolate(t, pts.map((p) => p[0]), pts.map((p) => p[1]), {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
/** pop-in / pop-out scale (0 outside [a,b)) */
export const vis = (t: number, a: number, b: number, d = 0.3) => {
  if (t < a || t >= b) return 0;
  return bo(prog(t, a, d)) * (1 - eo(prog(t, b - 0.2, 0.2)));
};
export const inR = (t: number, r: number[]) => t >= r[0] && t < r[1];
/** simple 3-shape lip-sync (0 closed, 1 small, 2 big) */
export const talk = (t: number, r: number[]): 0 | 1 | 2 => {
  if (!inR(t, r)) return 0;
  const k = Math.floor(t * 11);
  return ([2, 1, 0, 2, 1, 2, 0, 1][(k * 5 + 3) % 8]) as 0 | 1 | 2;
};
export const chew = (t: number): 0 | 1 => (Math.floor(t * 3) % 2 === 0 ? 1 : 0);
