import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {FPS, SceneStart, inR, kf, useT} from './util';

const FADE = 8;
const FadeIn: React.FC<{skip: boolean; children?: React.ReactNode}> = ({skip, children}) => {
  const f = useCurrentFrame();
  return <AbsoluteFill style={{opacity: skip ? 1 : Math.min(1, f / FADE), overflow: 'hidden'}}>{children}</AbsoluteFill>;
};

export const Scene: React.FC<{a: number; b: number; children?: React.ReactNode}> = ({a, b, children}) => {
  const from = Math.round(a * FPS);
  const end = Math.round(b * FPS);
  return (
    <Sequence from={from} durationInFrames={end - from + FADE}>
      <SceneStart.Provider value={from}>
        <FadeIn skip={a === 0}>{children}</FadeIn>
      </SceneStart.Provider>
    </Sequence>
  );
};

/** camera: zoom keyframes [t, zoom], screen-shake ranges */
export const Cam: React.FC<{z?: [number, number][]; ox?: number; oy?: number; shake?: number[][]; amp?: number; children?: React.ReactNode}> = ({z, ox = 960, oy = 540, shake = [], amp = 6, children}) => {
  const t = useT();
  const f = t * FPS;
  const sh = shake.some((r) => inR(t, r));
  const zoom = Math.max(z ? kf(t, z) : 1, sh ? 1.03 : 1);
  const dx = sh ? Math.sin(f * 1.9) * amp : 0;
  const dy = sh ? Math.cos(f * 2.7) * amp * 0.8 : 0;
  return <AbsoluteFill style={{transform: `translate(${dx}px,${dy}px) scale(${zoom})`, transformOrigin: `${ox}px ${oy}px`}}>{children}</AbsoluteFill>;
};
