import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import './font';
import {FONT} from './util';
import {Scene} from './Scene';
import {Caption} from './ui';
import {Scene1} from './scenes/Scene1';
import {Scene2} from './scenes/Scene2';
import {Scene3} from './scenes/Scene3';
import {Scene4} from './scenes/Scene4';
import {Scene5} from './scenes/Scene5';
import {Scene6} from './scenes/Scene6';

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily: FONT, fontWeight: 600}}>
    <Audio src={staticFile('voice.mp3')} volume={1} />
    <Scene a={0} b={13.0}><Scene1 /></Scene>
    <Scene a={13.0} b={33.5}><Scene2 /></Scene>
    <Scene a={33.5} b={53.2}><Scene3 /></Scene>
    <Scene a={53.2} b={87.5}><Scene4 /></Scene>
    <Scene a={87.5} b={122.84}><Scene5 /></Scene>
    <Scene a={122.84} b={147}><Scene6 /></Scene>
    <Caption />
  </AbsoluteFill>
);
