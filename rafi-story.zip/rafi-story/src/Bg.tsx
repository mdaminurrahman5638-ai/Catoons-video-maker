import React from 'react';
import {AbsoluteFill} from 'remotion';
import {OL} from './util';

const svgS: React.CSSProperties = {position: 'absolute', inset: 0, width: '100%', height: '100%'};
const o = {stroke: OL, strokeWidth: 4, strokeLinejoin: 'round' as const};
const VB = {viewBox: '0 0 1920 1080', preserveAspectRatio: 'xMidYMid slice'};

export const BgClean: React.FC = () => (
  <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #FFFDF6 0%, #FFE9BF 70%, #FBD79A 100%)'}} />
);

export const BgHome: React.FC = () => (
  <svg style={svgS} {...VB}>
    <rect width={1920} height={1080} fill="#FFE7C2" />
    <rect y={840} width={1920} height={240} fill="#C98B57" />
    <line x1={0} x2={1920} y1={840} y2={840} {...o} />
    {/* window + curtains */}
    <rect x={170} y={190} width={380} height={350} fill="#BFE6FF" {...o} />
    <circle cx={440} cy={300} r={46} fill="#FFD23F" />
    <line x1={360} x2={360} y1={190} y2={540} {...o} /><line x1={170} x2={550} y1={365} y2={365} {...o} />
    <rect x={140} y={170} width={50} height={390} rx={14} fill="#F28B82" {...o} />
    <rect x={530} y={170} width={50} height={390} rx={14} fill="#F28B82" {...o} />
    {/* calendar */}
    <rect x={760} y={150} width={160} height={200} rx={10} fill="#fff" {...o} />
    <rect x={760} y={150} width={160} height={50} rx={10} fill="#E53935" {...o} />
    {/* kitchen counter, pot, shelf */}
    <rect x={1380} y={560} width={480} height={290} fill="#8AA8C0" {...o} />
    <rect x={1370} y={540} width={500} height={34} rx={8} fill="#5F7F99" {...o} />
    <rect x={1560} y={440} width={140} height={100} rx={12} fill="#BDBDBD" {...o} />
    <rect x={1545} y={430} width={170} height={18} rx={9} fill="#9E9E9E" {...o} />
    <rect x={1400} y={320} width={440} height={18} rx={6} fill="#8D6E63" {...o} />
    <rect x={1430} y={250} width={70} height={70} rx={10} fill="#FFB74D" {...o} />
    <rect x={1530} y={240} width={70} height={80} rx={10} fill="#81C784" {...o} />
    <rect x={1630} y={255} width={70} height={65} rx={10} fill="#64B5F6" {...o} />
  </svg>
);

const BLD = [260, 340, 220, 300, 380, 240, 320, 270, 360, 230, 310, 280, 350, 250];
const BCOL = ['#F5C6A5', '#C5D8F0', '#F3E3A0', '#D7C4E8', '#BFE3CF'];

export const BgStreet: React.FC<{scroll?: number}> = ({scroll = 0}) => (
  <svg style={svgS} {...VB}>
    <defs>
      <linearGradient id="sky1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#BFE9FF" /><stop offset="1" stopColor="#FFF3D6" /></linearGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#sky1)" />
    <circle cx={300} cy={190} r={70} fill="#FFE27A" opacity={0.9} />
    <g transform={`translate(${-scroll * 0.3},0)`}>
      {BLD.map((h, i) => (
        <g key={i}>
          <rect x={i * 210} y={800 - h} width={200} height={h} fill={BCOL[i % 5]} {...o} />
          <rect x={i * 210 + 30} y={800 - h + 40} width={44} height={50} fill="#fff" {...o} />
          <rect x={i * 210 + 110} y={800 - h + 40} width={44} height={50} fill="#fff" {...o} />
        </g>
      ))}
    </g>
    {/* trees + school signpost */}
    <g transform={`translate(${-scroll * 0.6},0)`}>
      {[760, 1880].map((tx) => (
        <g key={tx}><rect x={tx - 14} y={560} width={28} height={240} fill="#8D6E63" {...o} /><circle cx={tx} cy={520} r={110} fill="#7BC67E" {...o} /></g>
      ))}
      <rect x={146} y={560} width={16} height={240} fill="#6D6D6D" {...o} />
      <rect x={70} y={540} width={260} height={80} rx={14} fill="#43A047" {...o} />
      <text x={200} y={598} fontSize={52} textAnchor="middle" fill="#fff" fontFamily="inherit">স্কুল →</text>
    </g>
    {/* closed tea shop */}
    <g transform={`translate(${-scroll * 0.9},0)`}>
      <rect x={1290} y={500} width={540} height={300} fill="#8D6E63" {...o} />
      {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => <line key={i} x1={1290} x2={1830} y1={530 + i * 32} y2={530 + i * 32} stroke="#6D4C41" strokeWidth={4} />)}
      {Array.from({length: 9}).map((_, i) => <rect key={i} x={1280 + i * 62} y={430} width={62} height={72} fill={i % 2 ? '#fff' : '#E53935'} {...o} />)}
      <rect x={1440} y={350} width={240} height={70} rx={12} fill="#FFD166" {...o} />
      <text x={1560} y={402} fontSize={52} textAnchor="middle" fill={OL} fontFamily="inherit">চায়ের দোকান</text>
      <rect x={1690} y={610} width={90} height={60} fill="#fff" {...o} />
      <text x={1735} y={652} fontSize={34} textAnchor="middle" fill="#E53935" fontFamily="inherit">বন্ধ</text>
    </g>
    {/* road */}
    <rect y={790} width={1920} height={30} fill="#D8D2C4" {...o} />
    <rect y={820} width={1920} height={260} fill="#A7ADB5" />
    {Array.from({length: 12}).map((_, i) => <rect key={i} x={((i * 260 - scroll * 1.4) % 3120 + 3120) % 3120 - 200} y={1000} width={130} height={16} rx={6} fill="#fff" />)}
  </svg>
);

export const BgSchool: React.FC = () => (
  <svg style={svgS} {...VB}>
    <defs>
      <linearGradient id="sky2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#9FDCFF" /><stop offset="1" stopColor="#E8F7FF" /></linearGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#sky2)" />
    <circle cx={260} cy={180} r={80} fill="#FFE27A" />
    <rect y={800} width={1920} height={280} fill="#8BD17C" />
    {[0, 1, 2, 3].map((i) => <rect key={i} y={830 + i * 70} width={1920} height={30} fill="#7CC46E" />)}
    {/* school building */}
    <rect x={880} y={380} width={840} height={420} fill="#F6D7A7" {...o} />
    <polygon points="860,380 1300,240 1740,380" fill="#D9534F" {...o} />
    {[0, 1, 2, 3].map((i) => <rect key={i} x={930 + i * 200} y={440} width={90} height={100} fill="#BFE6FF" {...o} />)}
    {[0, 1, 2, 3].map((i) => (i === 1 || i === 2 ? null : <rect key={i} x={930 + i * 200} y={610} width={90} height={100} fill="#BFE6FF" {...o} />))}
    <rect x={1260} y={640} width={90} height={160} fill="#8D6E63" {...o} />
    <rect x={1175} y={320} width={250} height={60} rx={10} fill="#fff" {...o} />
    <text x={1300} y={366} fontSize={46} textAnchor="middle" fill={OL} fontFamily="inherit">স্কুল</text>
    <line x1={1300} y1={80} x2={1300} y2={240} {...o} />
    <rect x={1300} y={84} width={90} height={56} fill="#E53935" {...o} />
    {/* gate + tree */}
    <rect x={150} y={560} width={60} height={250} fill="#B0BEC5" {...o} />
    <rect x={690} y={560} width={60} height={250} fill="#B0BEC5" {...o} />
    {[250, 330, 410, 490, 570, 650].map((x) => <line key={x} x1={x} y1={600} x2={x} y2={800} {...o} />)}
    <line x1={210} y1={620} x2={690} y2={620} {...o} />
    <rect x={1810} y={560} width={30} height={250} fill="#8D6E63" {...o} />
    <circle cx={1825} cy={520} r={110} fill="#7BC67E" {...o} />
  </svg>
);
