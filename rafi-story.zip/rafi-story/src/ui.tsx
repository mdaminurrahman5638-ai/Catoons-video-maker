import React, {CSSProperties} from 'react';
import {CAPS, HIDE} from './data';
import {OL, eo, prog, useT, vis} from './util';

export const Pop: React.FC<{s: number; e: number; style?: CSSProperties; origin?: string; d?: number; children?: React.ReactNode}> = ({s, e, style, origin = '50% 50%', d = 0.35, children}) => {
  const t = useT();
  const v = vis(t, s, e, d);
  if (v <= 0.001) return null;
  return <div style={{position: 'absolute', transform: `scale(${v})`, opacity: Math.min(1, v * 2), transformOrigin: origin, ...style}}>{children}</div>;
};

export const Float: React.FC<{amp?: number; speed?: number; rot?: number; children?: React.ReactNode}> = ({amp = 8, speed = 4, rot = 0, children}) => {
  const t = useT();
  return <div style={{transform: `translateY(${Math.sin(t * speed) * amp}px) rotate(${rot + Math.sin(t * speed * 0.7) * 4}deg)`}}>{children}</div>;
};

export const cardS: CSSProperties = {
  background: '#fff', border: `6px solid ${OL}`, borderRadius: 48, boxShadow: `14px 14px 0 ${OL}`,
  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 30, padding: 30, color: OL,
};

export const Pill: React.FC<{s: number; e: number; left: number; top: number; w: number; text: string; bg?: string; size?: number}> = ({s, e, left, top, w, text, bg = '#FFD166', size = 48}) => (
  <Pop s={s} e={e} style={{left, top}}>
    <div style={{width: w, textAlign: 'center', background: bg, border: `5px solid ${OL}`, borderRadius: 999, padding: '6px 0', fontSize: size, color: OL, boxShadow: `6px 6px 0 ${OL}`, whiteSpace: 'nowrap'}}>{text}</div>
  </Pop>
);

export const Bubble: React.FC<{s: number; e: number; left: number; bottom: number; w: number; tail: number; text: string; bg?: string; size?: number}> = ({s, e, left, bottom, w, tail, text, bg = '#fff', size = 46}) => (
  <Pop s={s} e={e} style={{left, bottom, width: w}} origin={`${tail}px 100%`}>
    <div style={{position: 'relative', background: bg, border: `6px solid ${OL}`, borderRadius: 44, padding: '22px 30px', fontSize: size, lineHeight: 1.35, color: OL, textAlign: 'center', boxShadow: `8px 8px 0 ${OL}`}}>
      {text}
      <svg width={56} height={44} viewBox="0 0 56 44" style={{position: 'absolute', left: tail - 28, bottom: -44, overflow: 'visible'}}>
        <path d="M3 0 L28 40 L53 0" fill={bg} stroke={OL} strokeWidth={6} strokeLinejoin="round" />
        <rect x={11} y={-2} width={34} height={9} fill={bg} />
      </svg>
    </div>
  </Pop>
);

export const Thought: React.FC<{s: number; e: number; left: number; bottom: number; w: number; h: number; children?: React.ReactNode}> = ({s, e, left, bottom, w, h, children}) => (
  <Pop s={s} e={e} style={{left, bottom}} origin={`${w / 2}px 100%`}>
    <div style={{position: 'relative', width: w, height: h, background: '#fff', border: `6px solid ${OL}`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `8px 8px 0 ${OL}`}}>
      {children}
      <div style={{position: 'absolute', left: w / 2 - 30, bottom: -52, width: 28, height: 28, borderRadius: '50%', background: '#fff', border: `5px solid ${OL}`}} />
      <div style={{position: 'absolute', left: w / 2 - 12, bottom: -88, width: 16, height: 16, borderRadius: '50%', background: '#fff', border: `5px solid ${OL}`}} />
    </div>
  </Pop>
);

export const Stamp: React.FC<{s: number; e: number; left: number; top: number; text: string; color?: string; rot?: number; size?: number}> = ({s, e, left, top, text, color = '#E53935', rot = -6, size = 70}) => (
  <Pop s={s} e={e} d={0.25} style={{left, top}}>
    <div style={{transform: `rotate(${rot}deg)`, border: `8px solid ${color}`, color, background: 'rgba(255,255,255,0.95)', borderRadius: 24, padding: '8px 36px', fontSize: size, whiteSpace: 'nowrap', boxShadow: `8px 8px 0 ${OL}`}}>{text}</div>
  </Pop>
);

/** selective floating overlay caption: hidden while any callout / bubble / card is visible */
export const Caption: React.FC = () => {
  const t = useT();
  if (HIDE.some((r) => t >= r[0] && t < r[1])) return null;
  const c = CAPS.find((x) => t >= x[0] && t < x[1]);
  if (!c) return null;
  const p = eo(prog(t, c[0], 0.25));
  const out = 1 - prog(t, c[1] - 0.12, 0.12);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 70, textAlign: 'center', fontSize: 66, whiteSpace: 'nowrap', opacity: p * out, transform: `translateY(${(1 - p) * 24}px)`}}>
      {c[2].split('*').map((x, i) => (
        <span key={i} style={{color: i % 2 ? '#FFD23F' : '#fff', fontWeight: i % 2 ? 700 : 600, WebkitTextStroke: '10px #222', paintOrder: 'stroke fill'}}>{x}</span>
      ))}
    </div>
  );
};
