import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgStreet} from '../Bg';
import {Character} from '../Character';
import {TH4, T} from '../data';
import {ICoinX, IHandX, IPlate, ITiffin} from '../icons';
import {Rickshaw} from '../Rickshaw';
import {Cam} from '../Scene';
import {Bubble, Float, Pill, Pop, Thought} from '../ui';
import {inR, kf, prog, talk, useT} from '../util';

export const Scene4: React.FC = () => {
  const t = useT();
  const jp = prog(t, 84.8, 1.0);
  const rx = kf(t, [[84.8, 980], [85.8, 1085]]);
  const ry = (t >= 85.8 ? 858 : 940) - (jp > 0 && jp < 1 ? Math.sin(Math.PI * jp) * 90 : 0);
  const sit = t >= 85.6;
  const rArmR = t < 53.6 ? 8 : t < 54.4 ? 150 : t < 62.8 ? 80 : t < 64.4 ? kf(t, [[62.8, 80], [64.4, 55]]) : t < 84 ? 55 : 45;
  const thinking = t >= 75.2 && t < 84;
  const rExp = t < 57.5 ? 'smile' : t < 59.7 ? 'happy' : t < 84 ? 'worry' : t < 85 ? 'surprise' : 'happy';
  const hArmL = t < 59.4 ? -25 : t < 66 ? kf(t, [[59.4, -25], [60.2, 70]]) : t < 68.5 ? 70 : -25;
  const hExp = t < 59.7 ? 'tired' : t < 69.9 ? 'sad' : 'tired';
  const sh = inR(t, T.h1);
  return (
    <AbsoluteFill>
      <Cam z={[[53.2, 1], [64.6, 1], [65.6, 1.28], [68.0, 1.28], [69.0, 1]]} ox={1200} oy={560} shake={[T.h1]} amp={5}>
        <BgStreet />
        <Rickshaw x={1300} y={900} />
        <Character kind="hashem" x={1200} y={867} s={0.88} sit rot={-4} exp={hExp} mouth={talk(t, T.h1) || talk(t, T.h2)} armL={hArmL} armR={15} tremble={sh ? 1.2 : 0} cry={t >= 71 && t < 74.8} />
        <Character kind="rafi" x={rx} y={ry} s={0.82} sit={sit} exp={rExp} mouth={talk(t, T.rafi1)} armL={thinking ? -115 : 8} lenL={thinking ? 0.6 : 1} armR={rArmR} holdR={t >= 54.2 ? <ITiffin size={84} /> : undefined} />
        <Pill s={61} e={64.6} left={940} top={398} w={520} text="রিকশাচালক চাচা হাশেম" bg="#BFE0FF" size={42} />
        <Bubble s={T.rafi1[0]} e={T.rafi1[1]} left={420} bottom={560} w={520} tail={560} text="চাচা, এটা খান না!" />
        <Bubble s={T.h1[0]} e={T.h1[1]} left={880} bottom={660} w={640} tail={320} text="না বাবা, ভিক্ষা নিই না আমি।" bg="#E4F1FF" />
        <Bubble s={T.h2[0]} e={T.h2[1]} left={840} bottom={660} w={720} tail={360} text="কাল রাতে ভাড়ার টাকাটা কোথায় পড়ে গেল, তাই আজ আর রিকশা নামাইনি।" bg="#E4F1FF" size={42} />
        <Pop s={71.4} e={74.5} style={{left: 1600, top: 430}}><Float><ICoinX size={170} /></Float></Pop>
        <Thought s={TH4[0]} e={TH4[1]} left={770} bottom={560} w={300} h={230}>
          {t < 81.6 ? <IPlate size={170} /> : <IHandX size={170} />}
        </Thought>
      </Cam>
    </AbsoluteFill>
  );
};
