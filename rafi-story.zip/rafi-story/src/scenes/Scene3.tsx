import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgStreet} from '../Bg';
import {Character} from '../Character';
import {ST1, TH3} from '../data';
import {IQuestion} from '../icons';
import {Rickshaw} from '../Rickshaw';
import {Cam} from '../Scene';
import {Pill, Stamp, Thought} from '../ui';
import {inR, kf, useT} from '../util';

export const Scene3: React.FC = () => {
  const t = useT();
  const rx = kf(t, [[33.5, -150], [36.6, 700], [47.8, 700], [49.7, 1560], [51.2, 1560], [53.2, 980]]);
  const moving = t < 36.6 || (t >= 47.8 && t < 49.7) || t >= 51.2;
  const hop = moving ? Math.abs(Math.sin(t * 10)) * 12 : 0;
  const sw = moving ? Math.sin(t * 10) * 25 : 0;
  return (
    <AbsoluteFill>
      <Cam z={[[33.5, 1], [53.2, 1.05]]} oy={650}>
        <BgStreet />
        <Rickshaw x={1300} y={900} />
        <Character kind="hashem" x={1200} y={867} s={0.88} sit rot={-4} exp="tired" armL={-25} armR={15} tremble={inR(t, ST1) ? 0.8 : 0} />
        <Character kind="rafi" x={rx} y={940 - hop} s={0.82} exp={t < 37.5 ? 'smile' : 'worry'} armL={moving ? -sw : 8} armR={moving ? 15 + sw : 8} />
        <Pill s={33.9} e={37.3} left={60} top={60} w={380} text="স্কুলের মোড়" bg="#fff" size={44} />
        <Stamp s={ST1[0]} e={ST1[1]} left={1330} top={300} text="খিদে পেয়েছে" />
        <Thought s={TH3[0]} e={TH3[1]} left={rx - 110} bottom={600} w={220} h={190}><IQuestion size={140} /></Thought>
      </Cam>
    </AbsoluteFill>
  );
};
