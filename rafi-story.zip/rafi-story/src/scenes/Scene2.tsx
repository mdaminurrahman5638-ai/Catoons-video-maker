import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgHome} from '../Bg';
import {Character} from '../Character';
import {T} from '../data';
import {IFood, ITiffin} from '../icons';
import {Cam} from '../Scene';
import {Bubble, Float, Pill, Pop} from '../ui';
import {inR, kf, talk, useT} from '../util';

export const Scene2: React.FC = () => {
  const t = useT();
  const walking = t >= 30;
  const rx = kf(t, [[29.9, 600], [30, 600], [33.4, 1700]]);
  const hop = walking ? Math.abs(Math.sin(t * 10)) * 12 : 0;
  const swing = walking ? Math.sin(t * 10) * 25 : 0;
  const rArmR = t < 16.9 ? 10 : t < 17.6 ? 130 : t < 18.6 ? 50 : t < 19.9 ? 10 : t < 22.2 ? 80 : t < 28.6 ? 30 : t < 29.4 ? 150 : walking ? 15 + swing : 10;
  const rArmL = walking ? -30 : 10;
  const mx = kf(t, [[18.6, 2200], [19.9, 930]]);
  const mHop = t >= 18.6 && t < 19.9 ? Math.abs(Math.sin(t * 14)) * 22 : 0;
  const mArmL = t < 19.9 ? 40 : t < 22.2 ? 80 : 10;
  const mArmR = inR(t, T.ma) ? 25 + Math.sin(t * 6) * 15 : t >= 30 ? 150 + Math.sin(t * 9) * 20 : 10;

  return (
    <AbsoluteFill>
      <Cam z={[[13, 1], [33.5, 1.07]]} oy={620}>
        <BgHome />
        <Character kind="ma" x={mx} y={900 - mHop} s={0.95} exp={inR(t, T.ma) ? 'happy' : 'smile'} mouth={talk(t, T.ma)} armL={mArmL} armR={mArmR} holdL={t >= 18.6 && t < 22.2 ? <ITiffin size={84} /> : undefined} />
        <Character kind="rafi" x={rx} y={900 - hop} s={0.82} exp={t >= 19.9 && t < 23 ? 'happy' : 'smile'} armL={rArmL} armR={rArmR} holdR={t >= 22.2 && t < 28.9 ? <ITiffin size={84} /> : undefined} />
        <Pill s={13.8} e={17} left={510} top={455} w={180} text="রাফি" bg="#FFD166" />
        <Pill s={19.9} e={22.9} left={860} top={395} w={140} text="মা" bg="#F8A5C2" />
        <Pill s={13.2} e={17.2} left={60} top={60} w={540} text="সকাল • রাফিদের বাসা" bg="#fff" size={42} />
        <Pop s={26.3} e={28.6} style={{left: 360, top: 380}}><Float><IFood size={190} /></Float></Pop>
        <Bubble s={T.ma[0]} e={T.ma[1]} left={620} bottom={690} w={660} tail={310} text="সব শেষ করবি কিন্তু, আজ তোর পছন্দের ডিম ভাজি আর পরোটা আছে।" bg="#FFE3EE" />
      </Cam>
    </AbsoluteFill>
  );
};
