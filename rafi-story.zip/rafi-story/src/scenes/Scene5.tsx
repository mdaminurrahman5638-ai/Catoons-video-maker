import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgStreet} from '../Bg';
import {Character} from '../Character';
import {ST2, T} from '../data';
import {IGamchha, IHalf, IHalfOne, IHeart, ITiffin} from '../icons';
import {Rickshaw} from '../Rickshaw';
import {Cam} from '../Scene';
import {Bubble, Float, Pop, Stamp} from '../ui';
import {chew, inR, kf, prog, talk, useT} from '../util';

export const Scene5: React.FC = () => {
  const t = useT();
  const riding = t >= 117.2;
  const ride = Math.max(0, t - 117.2);
  const scroll = ride * ride * 45;
  const bob = riding ? Math.sin(t * 16) * 3 : 0;
  const hx = kf(t, [[114.9, 1200], [115.9, 1365]]);
  const hp = prog(t, 114.9, 1.0);
  const hy = 867 - (hp > 0 && hp < 1 ? Math.sin(Math.PI * hp) * 70 : 0) + bob;

  // Rafi
  const rEat = t >= 99.8 && t < 104.3;
  const rArmR = t < 93 ? 40 : t < 98.1 ? 55 : t < 99.3 ? 85 : t < 99.8 ? 20 : rEat ? -120 : 20;
  const rHold = t >= 93 && t < 98.1 ? <ITiffin size={84} /> : (t >= 98.1 && t < 99.3) || rEat ? <IHalfOne size={64} /> : undefined;
  const rTalk = talk(t, T.rafi2) || talk(t, T.rafi3);
  const rMouth = rTalk || (rEat ? chew(t) : 0);

  // Hashem
  const hEat = t >= 104.5 && t < 112.4;
  const hArmL = t < 98.4 ? -25 : t < 104.5 ? 85 : hEat ? -120 : t < 114.9 ? 20 : -25;
  const hHoldL = t >= 99 && t < 112.4 ? <IHalfOne size={64} /> : undefined;
  const wipe = t >= 112.6 && t < 114.9;
  const hArmR = wipe ? -70 + Math.sin(t * 12) * 20 : riding ? 80 : 15;
  const hMouth = talk(t, T.h3) || talk(t, T.h4) || (hEat ? chew(t) : 0);
  const hExp = t < 99 ? 'tired' : t < 104.5 ? 'smile' : 'happy';

  return (
    <AbsoluteFill>
      <Cam z={[[87.5, 1], [106, 1], [109, 1.12], [112.6, 1.12], [113.5, 1]]} ox={1150} oy={600} shake={[[117.4, 122.8]]} amp={2.5}>
        <BgStreet scroll={scroll} />
        <Rickshaw x={1300} y={900} rot={scroll * 0.637} bob={bob} />
        <Character kind="hashem" x={hx} y={hy} s={0.88} sit rot={-3} exp={hExp} mouth={hMouth} cry={t >= 106.3 && t < 112.4} armL={hArmL} lenL={hEat ? 0.6 : 1} holdL={hHoldL} armR={hArmR} holdR={wipe ? <IGamchha size={90} /> : undefined} />
        <Character kind="rafi" x={1085} y={858 + bob} s={0.82} sit exp="happy" mouth={rMouth} armL={8} armR={t < 93 && inR(t, T.rafi2) ? 40 + Math.sin(t * 6) * 12 : rArmR} lenR={rEat ? 0.6 : 1} holdR={rHold} />
        <Bubble s={T.rafi2[0]} e={T.rafi2[1]} left={600} bottom={640} w={620} tail={485} text="তাহলে আমরা একসাথে খাই, চাচা! আমি একা খেতে পারি না।" />
        <Bubble s={T.rafi3[0]} e={T.rafi3[1]} left={620} bottom={640} w={560} tail={465} text="মা আজ অনেক মজা করে বানিয়েছেন।" />
        <Bubble s={T.h3[0]} e={T.h3[1]} left={900} bottom={660} w={660} tail={300} text="এমন পরোটা অনেকদিন খাইনি, বাবা।" bg="#E4F1FF" />
        <Bubble s={T.h4[0]} e={T.h4[1]} left={1000} bottom={660} w={760} tail={365} text="চলো বাবা, তোমাকে স্কুলের গেট পর্যন্ত পৌঁছে দিই। আজ আমার টাকা লাগবে না।" bg="#E4F1FF" size={42} />
        <Stamp s={ST2[0]} e={ST2[1]} left={640} top={260} text="ভাগ করে নেওয়া" color="#2E9E5B" rot={-5} />
        <Pop s={95.2} e={ST2[1]} style={{left: 1050, top: 360}}><Float><IHalf size={200} gap={prog(t, 95.2, 0.8) * 40} /></Float></Pop>
        {[[820, 560, 106.5], [900, 450, 107.8], [1540, 540, 107.0]].map(([l, tp, s], i) => (
          <Pop key={i} s={s} e={112.4} style={{left: l, top: tp}}><Float amp={14} speed={3 + i}><IHeart size={90} /></Float></Pop>
        ))}
      </Cam>
    </AbsoluteFill>
  );
};
