import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgClean} from '../Bg';
import {Float, Pop, cardS} from '../ui';
import {IBook, IBubbleDots, IClock, IPlate, IQuestion, IStar} from '../icons';
import {useT} from '../util';

const hl = {color: '#FF6B35'};

export const Scene1: React.FC = () => {
  const t = useT();
  return (
    <AbsoluteFill>
      <BgClean />
      {/* A: প্রশ্ন কার্ড */}
      <Pop s={0.2} e={4.8} style={{left: 300, top: 250}}>
        <div style={{...cardS, width: 1320, height: 560, flexDirection: 'column'}}>
          <div style={{display: 'flex', gap: 70, alignItems: 'center'}}><Float><IPlate size={190} /></Float><Float speed={3}><IClock size={190} /></Float></div>
          <div style={{fontSize: 104}}>সকাল থেকে <span style={hl}>কিছু খায়নি</span>?</div>
        </div>
      </Pop>
      <Pop s={0.9} e={4.8} style={{left: 1480, top: 120}}><Float amp={12} rot={12}><IQuestion size={260} /></Float></Pop>
      {/* B: মুখ ফুটে বলছে না */}
      <Pop s={4.8} e={6.95} style={{left: 360, top: 300}}>
        <div style={{...cardS, width: 1200, height: 420}}>
          <Float><IBubbleDots size={220} /></Float>
          <div style={{fontSize: 96}}>মুখ ফুটে <span style={hl}>বলছে না</span></div>
        </div>
      </Pop>
      {/* C: আজকের গল্প */}
      <Pop s={6.95} e={11.0} style={{left: 360, top: 250}}>
        <div style={{...cardS, width: 1200, height: 560, flexDirection: 'column'}}>
          <Float><IBook size={220} /></Float>
          <div style={{fontSize: 120}}>আজকের <span style={hl}>গল্প</span></div>
          <div style={{fontSize: 56, color: '#666'}}>তোমাদেরই মতো একটা ছোট্ট ছেলে</div>
        </div>
      </Pop>
      {/* D: টাইটেল */}
      <Pop s={11.0} e={13.3} style={{left: 0, top: 0, width: 1920, height: 1080}}>
        <div style={{position: 'absolute', left: 960 - 800, top: 540 - 800, width: 1600, height: 1600, borderRadius: '50%', opacity: 0.35, transform: `rotate(${t * 20}deg)`, background: 'repeating-conic-gradient(#FFC93C 0 10deg, transparent 10deg 20deg)', WebkitMaskImage: 'radial-gradient(circle, #000 25%, transparent 65%)'}} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 380, textAlign: 'center', fontSize: 210, color: '#222', WebkitTextStroke: '0px', textShadow: '10px 10px 0 #FFC93C'}}>ছোট্ট নায়ক</div>
        <div style={{position: 'absolute', left: 300, top: 360}}><Float amp={14} rot={-10}><IStar size={170} /></Float></div>
        <div style={{position: 'absolute', left: 1450, top: 560}}><Float amp={14} speed={5} rot={10}><IStar size={170} /></Float></div>
      </Pop>
    </AbsoluteFill>
  );
};
