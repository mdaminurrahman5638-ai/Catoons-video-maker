import React from 'react';
import {AbsoluteFill} from 'remotion';
import {BgClean, BgSchool} from '../Bg';
import {Character} from '../Character';
import {ICheck, IFood, IHalf, IHandX, IHeart, IPlate, ISmile, IStar} from '../icons';
import {Float, Pill, Pop, cardS} from '../ui';
import {prog, useT} from '../util';

const hl = {color: '#FF6B35'};

const CmpCard: React.FC<{s: number; left: number; bg: string; title: React.ReactNode; icon: React.ReactNode; foot: string; footColor: string}> = ({s, left, bg, title, icon, foot, footColor}) => (
  <Pop s={s} e={143.3} style={{left, top: 190}}>
    <div style={{...cardS, background: bg, width: 760, height: 640, flexDirection: 'column', gap: 24}}>
      <div style={{fontSize: 62, textAlign: 'center'}}>{title}</div>
      <Float>{icon}</Float>
      <div style={{fontSize: 90, color: footColor}}>{foot}</div>
    </div>
  </Pop>
);

export const Scene6: React.FC = () => {
  const t = useT();
  const playA = t < 131.5;
  const bgOp = 1 - prog(t, 131.2, 0.5);
  const hop = Math.abs(Math.sin(t * 6)) * 40;
  const w = Math.sin(t * 8) * 30;
  return (
    <AbsoluteFill>
      <BgClean />
      <AbsoluteFill style={{opacity: bgOp}}>
        <BgSchool />
        {playA && (
          <>
            <Character kind="kid" x={420} y={890 - Math.abs(Math.sin(t * 5 + 1)) * 30} s={0.75} tone="#F4B942" bottom="#6D4C41" exp="happy" armL={60 + w} armR={60 - w} />
            <Character kind="kid" x={1250} y={880 - Math.abs(Math.sin(t * 5 + 2)) * 30} s={0.75} tone="#7BC67E" bottom="#37474F" exp="smile" armL={60 - w} armR={60 + w} />
            <Character kind="kid" x={1560} y={915 - Math.abs(Math.sin(t * 5 + 3)) * 30} s={0.75} tone="#E58AAB" bottom="#5C6BC0" hair="pigtail" exp="happy" armL={60 + w} armR={60 - w} />
            <Character kind="rafi" x={900} y={930 - hop} s={0.9} exp="happy" armL={60 + w} armR={60 - w} />
            <Pill s={123.2} e={127} left={60} top={60} w={480} text="স্কুল • টিফিনের সময়" bg="#fff" size={42} />
            <Pop s={125.3} e={127.9} style={{left: 1080, top: 520}}><Float><IPlate size={190} /></Float></Pop>
            <Pop s={127.9} e={131.4} style={{left: 770, top: 150}}><Float amp={14} speed={5}><ISmile size={260} /></Float></Pop>
            <Pop s={128.6} e={131.4} style={{left: 560, top: 300}}><Float amp={10} speed={4}><IHeart size={100} /></Float></Pop>
            <Pop s={128.9} e={131.4} style={{left: 1130, top: 280}}><Float amp={10} speed={6}><IHeart size={100} /></Float></Pop>
          </>
        )}
      </AbsoluteFill>

      {/* Q: কোটেশন কার্ড */}
      <Pop s={131.5} e={135.2} style={{left: 260, top: 260}}>
        <div style={{...cardS, width: 1400, height: 560, flexDirection: 'column'}}>
          <div style={{display: 'flex', gap: 40, alignItems: 'center'}}>
            <IFood size={170} />
            <div style={{fontSize: 76}}>সাহায্য করতে হলে</div>
          </div>
          <div style={{fontSize: 110}}><span style={hl}>সবটা দিয়ে দিতে</span> হয় না</div>
        </div>
      </Pop>

      {/* তুলনা */}
      <CmpCard s={135.3} left={140} bg="#FFE5E0" title={<>দয়া দেখিয়ে<br />হাত বাড়ালে</>} icon={<IHandX size={210} />} foot="মানুষ নেয় না" footColor="#E53935" />
      <CmpCard s={139.7} left={1020} bg="#E1F6E4" title={<>নিজের খাবার<br />ভাগ করে</>} icon={<div style={{display: 'flex', alignItems: 'center'}}><IHalf size={210} gap={30} /><ICheck size={120} /></div>} foot="একসাথে খাই" footColor="#2E9E5B" />
      <Pop s={139.7} e={143.3} style={{left: 880, top: 460}}>
        <div style={{width: 160, height: 160, borderRadius: '50%', background: '#FFD23F', border: '6px solid #222', boxShadow: '8px 8px 0 #222', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 70}}>VS</div>
      </Pop>

      {/* শিক্ষা কার্ড */}
      <Pop s={143.3} e={148} style={{left: 260, top: 250}}>
        <div style={{...cardS, width: 1400, height: 580, flexDirection: 'column', background: '#FFF6D6'}}>
          <Float amp={12} speed={5}><IHeart size={200} /></Float>
          <div style={{fontSize: 88}}><span style={hl}>আত্মসম্মানী</span> মানুষও</div>
          <div style={{fontSize: 100}}>হাসিমুখে <span style={hl}>হাত বাড়ায়</span></div>
        </div>
      </Pop>
      <Pop s={143.6} e={148} style={{left: 150, top: 150}}><Float amp={14} speed={4} rot={-12}><IStar size={130} /></Float></Pop>
      <Pop s={143.9} e={148} style={{left: 1650, top: 780}}><Float amp={14} speed={5} rot={12}><IStar size={130} /></Float></Pop>
    </AbsoluteFill>
  );
};
