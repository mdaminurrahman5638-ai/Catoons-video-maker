import React from 'react';
import {OL} from './util';

const tube = (d: string) => (
  <g fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} stroke={OL} strokeWidth={14} />
    <path d={d} stroke="#3B82C4" strokeWidth={7} />
  </g>
);

/** side-view cycle rickshaw facing right. origin = ground under the middle */
export const Rickshaw: React.FC<{x: number; y: number; rot?: number; bob?: number}> = ({x, y, rot = 0, bob = 0}) => {
  const wheel = (cx: number) => (
    <g key={cx}>
      <circle cx={cx} cy={-90} r={88} fill="none" stroke={OL} strokeWidth={14} />
      <circle cx={cx} cy={-90} r={76} fill="none" stroke="#9AA3AD" strokeWidth={4} />
      <g transform={`rotate(${rot} ${cx} -90)`}>
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <line key={i} x1={cx} y1={-90} x2={cx + 76 * Math.cos((i * Math.PI) / 4)} y2={-90 + 76 * Math.sin((i * Math.PI) / 4)} stroke="#6B7580" strokeWidth={3} />
        ))}
      </g>
      <circle cx={cx} cy={-90} r={11} fill="#FFC93C" stroke={OL} strokeWidth={4} />
    </g>
  );
  return (
    <svg width={1} height={1} style={{position: 'absolute', left: x, top: y + bob, overflow: 'visible'}}>
      {/* hood */}
      <path d="M-282,-192 Q-170,-440 -40,-192 Z" fill="#FFC93C" stroke={OL} strokeWidth={5} strokeLinejoin="round" />
      <path d="M-232,-194 Q-205,-340 -168,-352 M-110,-194 Q-135,-340 -168,-352" fill="none" stroke="#E0453A" strokeWidth={10} strokeLinecap="round" />
      {wheel(-155)}
      {wheel(250)}
      {tube('M-155,-90 L-60,-160 L190,-240')}
      {tube('M65,-170 L95,-100 L250,-90')}
      {tube('M250,-90 L225,-180 L205,-265')}
      {/* bench + backrest */}
      <rect x={-282} y={-300} width={26} height={118} rx={10} fill="#E0453A" stroke={OL} strokeWidth={5} />
      <rect x={-282} y={-192} width={246} height={34} rx={12} fill="#E0453A" stroke={OL} strokeWidth={5} />
      {/* driver saddle + pedal */}
      <rect x={28} y={-192} width={78} height={22} rx={10} fill="#222" />
      <circle cx={95} cy={-100} r={20} fill="none" stroke={OL} strokeWidth={6} />
      <g transform={`rotate(${rot * 2} 95 -100)`}>
        <line x1={95} y1={-100} x2={95} y2={-72} stroke={OL} strokeWidth={8} />
        <rect x={80} y={-76} width={30} height={10} rx={4} fill="#555" stroke={OL} strokeWidth={3} />
      </g>
      {/* handlebar */}
      <path d="M185,-268 L238,-268" stroke={OL} strokeWidth={13} strokeLinecap="round" />
      <path d="M185,-268 L238,-268" stroke="#888" strokeWidth={5} strokeLinecap="round" />
    </svg>
  );
};
