import React from 'react';
import {FONT, OL} from './util';

const S = {stroke: OL, strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
type P = {size?: number; gap?: number};
const Svg: React.FC<{size: number; children?: React.ReactNode}> = ({size, children}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible'}}>{children}</svg>
);

export const IPlate: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <ellipse cx="50" cy="58" rx="44" ry="30" fill="#fff" {...S} />
    <ellipse cx="50" cy="58" rx="28" ry="18" fill="#EEEEEE" {...S} />
  </Svg>
);
export const IClock: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="24" cy="18" r="11" fill="#E53935" {...S} />
    <circle cx="76" cy="18" r="11" fill="#E53935" {...S} />
    <circle cx="50" cy="54" r="38" fill="#fff" {...S} />
    <path d="M50 54 L50 30 M50 54 L68 62" fill="none" {...S} />
  </Svg>
);
export const IQuestion: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <text x="50" y="86" fontSize="100" textAnchor="middle" fill="#FF6B35" stroke={OL} strokeWidth="3" fontFamily={FONT}>?</text>
  </Svg>
);
export const IBook: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <path d="M50 28 Q30 16 8 22 L8 78 Q30 72 50 84 Z" fill="#FFD166" {...S} />
    <path d="M50 28 Q70 16 92 22 L92 78 Q70 72 50 84 Z" fill="#FFE29A" {...S} />
    <path d="M18 38 Q32 34 42 40 M18 52 Q32 48 42 54 M58 40 Q68 34 82 38 M58 54 Q68 48 82 52" fill="none" stroke={OL} strokeWidth="3" />
  </Svg>
);
export const IStar: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <polygon points="50,6 62,38 96,38 68,58 79,92 50,72 21,92 32,58 4,38 38,38" fill="#FFC93C" {...S} />
  </Svg>
);
export const IHeart: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <path d="M50 88 C8 56 6 26 28 18 C40 14 48 22 50 32 C52 22 60 14 72 18 C94 26 92 56 50 88Z" fill="#FF5C7A" {...S} />
  </Svg>
);
export const ISmile: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="50" cy="50" r="42" fill="#FFD23F" {...S} />
    <ellipse cx="36" cy="42" rx="5" ry="8" fill={OL} />
    <ellipse cx="64" cy="42" rx="5" ry="8" fill={OL} />
    <path d="M30 60 Q50 82 70 60" fill="none" {...S} />
    <ellipse cx="24" cy="60" rx="7" ry="4" fill="#FF9E9E" />
    <ellipse cx="76" cy="60" rx="7" ry="4" fill="#FF9E9E" />
  </Svg>
);
export const ICoin: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="50" cy="50" r="40" fill="#FFD23F" {...S} />
    <circle cx="50" cy="50" r="29" fill="none" stroke={OL} strokeWidth="3" />
    <text x="50" y="66" fontSize="46" textAnchor="middle" fill={OL} fontFamily={FONT}>৳</text>
  </Svg>
);
const Xmark = () => <path d="M20 20 L80 80 M80 20 L20 80" stroke="#E53935" strokeWidth="12" strokeLinecap="round" />;
export const ICross: React.FC<P> = ({size = 160}) => <Svg size={size}><Xmark /></Svg>;
export const ICoinX: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="50" cy="50" r="40" fill="#FFD23F" {...S} />
    <text x="50" y="66" fontSize="46" textAnchor="middle" fill={OL} fontFamily={FONT}>৳</text>
    <Xmark />
  </Svg>
);
export const ICheck: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="50" cy="50" r="40" fill="#43B26B" {...S} />
    <path d="M28 52 L44 68 L74 34" fill="none" stroke="#fff" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);
export const ITiffin: React.FC<P> = ({size = 90}) => (
  <Svg size={size}>
    <path d="M30 24 Q50 -6 70 24" fill="none" {...S} />
    <rect x="20" y="62" width="60" height="22" rx="6" fill="#B8C4D0" {...S} />
    <rect x="20" y="40" width="60" height="22" rx="6" fill="#CBD5DE" {...S} />
    <rect x="20" y="20" width="60" height="22" rx="8" fill="#8FA3B5" {...S} />
    <path d="M18 18 L18 86 M82 18 L82 86" stroke={OL} strokeWidth="3" />
  </Svg>
);
export const IFood: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <circle cx="40" cy="62" r="32" fill="#F2C46D" {...S} />
    <path d="M22 62 Q40 40 58 62 M26 74 Q40 56 54 74" fill="none" stroke="#C9923A" strokeWidth="3" />
    <path d="M58 30 Q66 14 84 22 Q96 34 82 48 Q66 54 58 30Z" fill="#fff" {...S} />
    <circle cx="74" cy="34" r="9" fill="#FFB300" {...S} />
  </Svg>
);
/** one half of a paratha (for holding) */
export const IHalfOne: React.FC<P> = ({size = 70}) => (
  <Svg size={size}>
    <path d="M50 14 A38 38 0 0 0 50 90 Z" fill="#F2C46D" {...S} />
    <path d="M36 30 Q26 52 36 74" fill="none" stroke="#C9923A" strokeWidth="3" />
  </Svg>
);
/** paratha split in two (gap = spread in px of viewBox) */
export const IHalf: React.FC<P> = ({size = 160, gap = 0}) => (
  <Svg size={size}>
    <g transform={`translate(${-gap / 2},0)`}><path d="M48 14 A38 38 0 0 0 48 90 Z" fill="#F2C46D" {...S} /></g>
    <g transform={`translate(${gap / 2},0)`}><path d="M52 14 A38 38 0 0 1 52 90 Z" fill="#F2C46D" {...S} /></g>
  </Svg>
);
export const IHandX: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    {[26, 38, 50, 62].map((x, i) => <rect key={x} x={x} y={14 + (i % 3 === 1 ? -6 : 0)} width="11" height="44" rx="5.5" fill="#F2C29B" {...S} />)}
    <rect x="26" y="44" width="47" height="42" rx="14" fill="#F2C29B" {...S} />
    <rect x="10" y="48" width="12" height="32" rx="6" transform="rotate(-25 16 64)" fill="#F2C29B" {...S} />
    <Xmark />
  </Svg>
);
export const IBubbleDots: React.FC<P> = ({size = 160}) => (
  <Svg size={size}>
    <path d="M14 20 H86 Q92 20 92 26 V62 Q92 68 86 68 H52 L34 86 L36 68 H14 Q8 68 8 62 V26 Q8 20 14 20Z" fill="#fff" {...S} />
    {[30, 50, 70].map((x) => <circle key={x} cx={x} cy={44} r={5} fill={OL} />)}
  </Svg>
);
export const IGamchha: React.FC<P> = ({size = 90}) => (
  <Svg size={size}>
    <path d="M18 24 Q50 8 82 24 L76 82 Q50 92 24 82 Z" fill="#fff" {...S} />
    <path d="M22 44 H78 M24 62 H76" stroke="#D95F5F" strokeWidth="5" />
  </Svg>
);
