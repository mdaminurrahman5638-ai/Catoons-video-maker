import {continueRender, delayRender, staticFile} from 'remotion';
import {loadFont} from '@remotion/fonts';

const h = delayRender('hind-siliguri');
loadFont({family: 'Hind Siliguri', url: staticFile('HindSiliguri-SemiBold.ttf'), weight: '600'})
  .then(() => continueRender(h))
  .catch((e) => {
    console.error(e);
    continueRender(h);
  });
