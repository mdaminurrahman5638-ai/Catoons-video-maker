import React from 'react';
import {OL, useT} from './util';

export type Exp = 'neutral' | 'smile' | 'happy' | 'sad' | 'worry' | 'surprise' | 'angry' | 'tired';
export interface CProps {
  kind: 'rafi' | 'ma' | 'hashem' | 'kid';
  x: number; y: number; s?: number;
  exp?: Exp; mouth?: 0 | 1 | 2;
  armL?: number; armR?: number; lenL?: number; lenR?: number;
  holdL?: React.ReactNode; holdR?: React.ReactNode;
  sit?: boolean; tremble?: number; cry?: boolean; rot?: number;
  tone?: string; bottom?: string; hair?: 'short' | 'pigtail';
}

const st = {stroke: OL, strokeWidth: 2.5, vectorEffect: 'non-scaling-stroke' as const, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
const SKIN = {rafi: '#F6C9A0', ma: '#EDB88E', hashem: '#C99263', kid: '#F2C29B'};
const SHIRT = {rafi: '#FFFFFF', ma: '#F6B8CB', hashem: '#9EC7E8', kid: '#F4B942'};

const brow = (e: Exp): [string, string] => {
  switch (e) {
    case 'happy': case 'smile': return ['M-40,-420 Q-25,-432 -10,-421', 'M10,-421 Q25,-432 40,-420'];
    case 'sad': case 'worry': return ['M-40,-413 L-10,-424', 'M10,-424 L40,-413'];
    case 'angry': return ['M-40,-425 L-10,-413', 'M10,-413 L40,-425'];
    case 'surprise': return ['M-40,-432 Q-25,-445 -10,-433', 'M10,-433 Q25,-445 40,-432'];
    case 'tired': return ['M-40,-414 L-10,-418', 'M10,-418 L40,-414'];
    default: return ['M-40,-421 L-10,-421', 'M10,-421 L40,-421'];
  }
};

const Mouth: React.FC<{e: Exp; m: 0 | 1 | 2}> = ({e, m}) => {
  if (m === 1) return <ellipse cx={0} cy={-344} rx={11} ry={7} fill="#7A2323" {...st} />;
  if (m === 2) return <g><ellipse cx={0} cy={-342} rx={17} ry={15} fill="#7A2323" {...st} /><ellipse cx={0} cy={-334} rx={9} ry={5} fill="#E8837F" /></g>;
  switch (e) {
    case 'smile': return <path d="M-20,-348 Q0,-330 20,-348" fill="none" {...st} />;
    case 'happy': return <path d="M-24,-350 Q0,-316 24,-350 Z" fill="#7A2323" {...st} />;
    case 'sad': case 'angry': return <path d="M-18,-340 Q0,-354 18,-340" fill="none" {...st} />;
    case 'worry': return <path d="M-18,-342 Q-9,-350 0,-342 Q9,-334 18,-342" fill="none" {...st} />;
    case 'surprise': return <ellipse cx={0} cy={-342} rx={9} ry={13} fill="#7A2323" {...st} />;
    case 'tired': return <path d="M-12,-343 L12,-345" fill="none" {...st} />;
    default: return <path d="M-14,-345 L14,-345" fill="none" {...st} />;
  }
};

const Arm: React.FC<{side: 'L' | 'R'; a: number; len: number; sleeve: string; sl: number; skin: string; hold?: React.ReactNode}> = ({side, a, len, sleeve, sl, skin, hold}) => {
  const x = side === 'L' ? -55 : 55;
  const rot = side === 'L' ? a : -a; // a: 0 = down, 90 = outward, negative = across body
  const L = 125 * len;
  return (
    <g transform={`translate(${x},-285) rotate(${rot})`}>
      <rect x={-13} y={-10} width={26} height={L + 10} rx={13} fill={skin} {...st} />
      <rect x={-13} y={-10} width={26} height={Math.min(L + 10, sl * len)} rx={13} fill={sleeve} {...st} />
      <circle cx={0} cy={L} r={15} fill={skin} {...st} />
      {hold ? <g transform={`translate(0,${L}) rotate(${-rot})`}>{hold}</g> : null}
    </g>
  );
};

export const Character: React.FC<CProps> = ({
  kind, x, y, s = 1, exp = 'neutral', mouth = 0, armL = 8, armR = 8, lenL = 1, lenR = 1, holdL, holdR,
  sit = false, tremble = 0, cry = false, rot = 0, tone = '#F4B942', bottom = '#4B6FB5', hair = 'short',
}) => {
  const t = useT();
  const f = t * 30;
  const ph = kind === 'ma' ? 1.3 : kind === 'hashem' ? 2.1 : kind === 'kid' ? 0.7 : 0;
  const fy = Math.sin(t * 2.6 + ph) * 4;
  const blink = (t + ph) % 3.4 < 0.13;
  const tx = tremble ? Math.sin(f * 2.3) * tremble : 0;
  const ty = tremble ? Math.cos(f * 3.1) * tremble * 0.6 : 0;
  const sk = SKIN[kind];
  const shirt = kind === 'kid' ? tone : SHIRT[kind];
  const sl = kind === 'ma' || kind === 'hashem' ? 85 : 55;
  const [b1, b2] = brow(exp);
  const legsT = sit ? 'translate(0,-150) scale(1,0.6) translate(0,150)' : undefined;
  const pants = kind === 'rafi' ? '#1F3A6E' : bottom;

  return (
    <svg width={1} height={1} style={{position: 'absolute', left: x, top: y, overflow: 'visible'}}>
      <g transform={`translate(${tx},${fy + ty}) rotate(${rot}) scale(${s})`}>
        {kind === 'hashem' && (
          <defs>
            <pattern id="chk" width="26" height="26" patternUnits="userSpaceOnUse">
              <rect width="26" height="26" fill="#3E8E7E" />
              <rect width="13" height="26" fill="#fff" opacity="0.4" />
              <rect width="26" height="13" fill="#fff" opacity="0.4" />
            </pattern>
          </defs>
        )}
        {/* school bag (behind) */}
        {kind === 'rafi' && <rect x={-72} y={-300} width={144} height={135} rx={18} fill="#E03B3B" {...st} />}

        {/* legs / lower clothes */}
        <g transform={legsT}>
          {kind === 'ma' ? (
            <g>
              <ellipse cx={-30} cy={-6} rx={24} ry={9} fill={sk} {...st} />
              <ellipse cx={30} cy={-6} rx={24} ry={9} fill={sk} {...st} />
              <path d="M-62,-172 L-92,-12 L92,-12 L62,-172 Z" fill="#F6B8CB" {...st} />
              <path d="M-20,-160 L-30,-16 M22,-160 L34,-16" stroke="#E898B2" strokeWidth={3} fill="none" />
            </g>
          ) : (
            [-24, 24].map((lx) => (
              <g key={lx} transform={`translate(${lx},0)`}>
                <rect x={-12} y={-112} width={24} height={102} rx={10} fill={sk} {...st} />
                {kind !== 'hashem' && <rect x={-12} y={-52} width={24} height={42} rx={8} fill="#fff" {...st} />}
                <ellipse cx={0} cy={-8} rx={kind === 'hashem' ? 24 : 26} ry={kind === 'hashem' ? 10 : 12} fill={kind === 'hashem' ? sk : '#222'} {...st} />
                {kind !== 'hashem' && <rect x={-19} y={-166} width={38} height={72} rx={12} fill={pants} {...st} />}
              </g>
            ))
          )}
          {kind === 'hashem' && <path d="M-60,-174 L-70,-84 L70,-84 L60,-174 Z" fill="url(#chk)" {...st} />}
        </g>

        {/* neck + torso */}
        <rect x={-14} y={-332} width={28} height={28} fill={sk} {...st} />
        <rect x={-55} y={-312} width={110} height={172} rx={34} fill={shirt} {...st} />
        {kind === 'rafi' && (
          <g>
            <path d="M-20,-312 L0,-288 L20,-312" fill="#fff" {...st} />
            <rect x={-40} y={-310} width={12} height={112} rx={5} fill="#B22A2A" {...st} />
            <rect x={28} y={-310} width={12} height={112} rx={5} fill="#B22A2A" {...st} />
          </g>
        )}
        {kind === 'ma' && <path d="M-52,-302 L50,-312 L62,-190 L60,-142 L22,-142 L20,-215 Z" fill="#F29AB5" {...st} />}
        {kind === 'hashem' && (
          <g>
            <path d="M0,-312 L0,-232" stroke={OL} strokeWidth={2.5} fill="none" />
            <circle cx={0} cy={-285} r={3.5} fill={OL} /><circle cx={0} cy={-255} r={3.5} fill={OL} />
            <rect x={18} y={-205} width={26} height={26} fill="#86AECF" stroke={OL} strokeWidth={2} strokeDasharray="5 3" />
            <path d="M8,-314 L52,-314 L66,-226 L38,-226 Z" fill="#fff" {...st} />
            <path d="M20,-300 L58,-300 M24,-280 L62,-280" stroke="#D95F5F" strokeWidth={4} />
          </g>
        )}

        {/* head */}
        {kind === 'ma' && <circle cx={0} cy={-470} r={28} fill="#1B1B1B" {...st} />}
        {kind === 'kid' && hair === 'pigtail' && (<g><circle cx={-76} cy={-410} r={20} fill="#222" {...st} /><circle cx={76} cy={-410} r={20} fill="#222" {...st} /></g>)}
        <circle cx={-62} cy={-382} r={12} fill={sk} {...st} />
        <circle cx={62} cy={-382} r={12} fill={sk} {...st} />
        <ellipse cx={0} cy={-385} rx={62} ry={68} fill={sk} {...st} />
        {kind === 'hashem' ? (
          <g>
            <path d="M-62,-384 C-66,-446 -30,-458 0,-458 C30,-458 66,-446 62,-384 C54,-414 36,-428 0,-424 C-36,-428 -54,-414 -62,-384 Z" fill="#B5B5B5" {...st} />
            <path d="M-52,-352 C-46,-318 -20,-312 0,-312 C20,-312 46,-318 52,-352 C40,-340 25,-336 0,-336 C-25,-336 -40,-340 -52,-352 Z" fill="#E8E8E8" {...st} />
            <path d="M-36,-372 Q-24,-365 -12,-372 M12,-372 Q24,-365 36,-372" stroke="#7A5236" strokeWidth={2.5} fill="none" />
          </g>
        ) : (
          <path d="M-64,-378 C-70,-472 70,-472 64,-378 C52,-418 22,-424 0,-416 C-22,-424 -52,-418 -64,-378 Z" fill={kind === 'ma' ? '#1B1B1B' : '#222'} {...st} />
        )}
        {kind === 'ma' && <circle cx={0} cy={-408} r={4.5} fill="#111" />}
        {/* face */}
        {(exp === 'happy' || exp === 'smile') && (<g><ellipse cx={-40} cy={-362} rx={12} ry={7} fill="#FF9E9E" opacity={0.6} /><ellipse cx={40} cy={-362} rx={12} ry={7} fill="#FF9E9E" opacity={0.6} /></g>)}
        {[-24, 24].map((ex) => (
          <g key={ex}>
            <ellipse cx={ex} cy={-388} rx={9} ry={blink ? 1.5 : exp === 'tired' ? 6 : exp === 'surprise' ? 15 : 12} fill={OL} />
            {!blink && exp !== 'tired' && <circle cx={ex + 3} cy={-392} r={3} fill="#fff" />}
          </g>
        ))}
        <path d={b1} fill="none" stroke={OL} strokeWidth={5} strokeLinecap="round" />
        <path d={b2} fill="none" stroke={OL} strokeWidth={5} strokeLinecap="round" />
        <Mouth e={exp} m={mouth} />
        {cry && [-30, 30].map((cx) => <path key={cx} d={`M${cx},${-372 + (f % 24) * 2} q-6,10 0,14 q6,-4 0,-14`} fill="#7EC8F0" stroke={OL} strokeWidth={1.5} />)}

        {/* arms (in front) */}
        <Arm side="L" a={armL} len={lenL} sleeve={shirt} sl={sl} skin={sk} hold={holdL} />
        <Arm side="R" a={armR} len={lenR} sleeve={shirt} sl={sl} skin={sk} hold={holdR} />
      </g>
    </svg>
  );
};
